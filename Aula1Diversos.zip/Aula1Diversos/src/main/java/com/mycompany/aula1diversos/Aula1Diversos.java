/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula1diversos;

/**
 *
 * @author Madianita Bogo
 */
public class Aula1Diversos {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
